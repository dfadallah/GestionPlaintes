"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Lock, User, MessageSquare, Globe } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function LoginPage() {
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
    language: "fr",
  })

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulation de connexion - redirection vers le dashboard
    window.location.href = "/dashboard"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-600 to-green-600 rounded-full mb-4">
            <MessageSquare className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">SWEDD+</h1>
          <p className="text-gray-600 mt-2">Plateforme de Gestion des Plaintes</p>
          <Badge variant="outline" className="mt-2">
            Autonomisation des Femmes et Dividende Démographique
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Connexion Sécurisée</CardTitle>
            <CardDescription>Accédez à votre espace de gestion des plaintes</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language">Langue / اللغة</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Select
                    value={credentials.language}
                    onValueChange={(value) => setCredentials({ ...credentials, language: value })}
                  >
                    <SelectTrigger className="pl-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="ar">العربية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">Nom d'utilisateur</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Votre nom d'utilisateur"
                    className="pl-10"
                    value={credentials.username}
                    onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    className="pl-10"
                    value={credentials.password}
                    onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-green-600">
                Se connecter
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-gray-600">
              <p className="font-medium mb-2">Comptes de démonstration :</p>
              <div className="space-y-1">
                <p>
                  <strong>Administrateur :</strong> admin@swedd.org
                </p>
                <p>
                  <strong>Agent de traitement :</strong> agent@swedd.org
                </p>
                <p>
                  <strong>Réceptionniste :</strong> reception@swedd.org
                </p>
                <p>
                  <strong>Coordinateur national :</strong> coordinateur@swedd.org
                </p>
                <p>
                  <strong>Observateur :</strong> observateur@swedd.org
                </p>
              </div>
            </div>

            <div className="mt-4 text-xs text-center text-gray-500">
              <p>🔒 Connexion sécurisée - Données chiffrées</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
