"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Filter, Edit, Trash2, Eye, Package, AlertTriangle } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Données simulées
const articles = [
  {
    id: 1,
    reference: "ORD-001",
    name: "Ordinateur portable Dell Latitude",
    category: "Informatique",
    supplier: "Dell France",
    currentStock: 15,
    minStock: 5,
    price: 899.99,
    status: "En stock",
  },
  {
    id: 2,
    reference: "CHA-002",
    name: "Chaise de bureau ergonomique",
    category: "Mobilier",
    supplier: "Office Depot",
    currentStock: 2,
    minStock: 10,
    price: 249.99,
    status: "Stock bas",
  },
  {
    id: 3,
    reference: "IMP-003",
    name: "Imprimante laser HP LaserJet",
    category: "Informatique",
    supplier: "HP France",
    currentStock: 8,
    minStock: 3,
    price: 199.99,
    status: "En stock",
  },
  {
    id: 4,
    reference: "PAP-004",
    name: "Papier A4 80g (500 feuilles)",
    category: "Fournitures",
    supplier: "Clairefontaine",
    currentStock: 0,
    minStock: 50,
    price: 4.99,
    status: "Rupture",
  },
]

const categories = ["Informatique", "Mobilier", "Fournitures", "Électronique"]
const suppliers = ["Dell France", "HP France", "Office Depot", "Clairefontaine"]

export default function ArticlesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newArticle, setNewArticle] = useState({
    reference: "",
    name: "",
    category: "",
    supplier: "",
    currentStock: "0",
    minStock: "0",
    price: "0",
  })

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.reference.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory =
      selectedCategory === "" || selectedCategory === "all" || article.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getStatusBadge = (status: string, currentStock: number, minStock: number) => {
    if (currentStock === 0) {
      return <Badge variant="destructive">Rupture</Badge>
    } else if (currentStock <= minStock) {
      return (
        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
          Stock bas
        </Badge>
      )
    } else {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800">
          En stock
        </Badge>
      )
    }
  }

  const handleAddArticle = () => {
    // Logique d'ajout d'article
    // Convertir les valeurs en nombres pour le traitement
    const processedArticle = {
      ...newArticle,
      currentStock: Number.parseInt(newArticle.currentStock) || 0,
      minStock: Number.parseInt(newArticle.minStock) || 0,
      price: Number.parseFloat(newArticle.price) || 0,
    }
    console.log("Nouvel article:", processedArticle)
    setIsDialogOpen(false)
    setNewArticle({
      reference: "",
      name: "",
      category: "",
      supplier: "",
      currentStock: "0",
      minStock: "0",
      price: "0",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestion des articles</h1>
          <p className="text-gray-600 mt-2">Gérez votre catalogue d'articles</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nouvel article
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Ajouter un nouvel article</DialogTitle>
              <DialogDescription>Remplissez les informations de l'article à ajouter au stock.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="reference" className="text-right">
                  Référence
                </Label>
                <Input
                  id="reference"
                  value={newArticle.reference}
                  onChange={(e) => setNewArticle({ ...newArticle, reference: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Nom
                </Label>
                <Input
                  id="name"
                  value={newArticle.name}
                  onChange={(e) => setNewArticle({ ...newArticle, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="category" className="text-right">
                  Catégorie
                </Label>
                <Select onValueChange={(value) => setNewArticle({ ...newArticle, category: value })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Sélectionner une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="supplier" className="text-right">
                  Fournisseur
                </Label>
                <Select onValueChange={(value) => setNewArticle({ ...newArticle, supplier: value })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Sélectionner un fournisseur" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((supplier) => (
                      <SelectItem key={supplier} value={supplier}>
                        {supplier}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="currentStock" className="text-right">
                  Stock initial
                </Label>
                <Input
                  id="currentStock"
                  type="number"
                  value={newArticle.currentStock}
                  onChange={(e) => setNewArticle({ ...newArticle, currentStock: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="minStock" className="text-right">
                  Stock minimum
                </Label>
                <Input
                  id="minStock"
                  type="number"
                  value={newArticle.minStock}
                  onChange={(e) => setNewArticle({ ...newArticle, minStock: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="price" className="text-right">
                  Prix unitaire
                </Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={newArticle.price}
                  onChange={(e) => setNewArticle({ ...newArticle, price: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddArticle}>
                Ajouter l'article
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtres et recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Rechercher par nom ou référence..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Toutes les catégories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les catégories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filtres avancés
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des articles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Package className="h-5 w-5 mr-2" />
            Articles ({filteredArticles.length})
          </CardTitle>
          <CardDescription>Liste de tous les articles en stock</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Référence</TableHead>
                <TableHead>Nom</TableHead>
                <TableHead>Catégorie</TableHead>
                <TableHead>Fournisseur</TableHead>
                <TableHead>Stock actuel</TableHead>
                <TableHead>Stock min.</TableHead>
                <TableHead>Prix unitaire</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredArticles.map((article) => (
                <TableRow key={article.id}>
                  <TableCell className="font-medium">{article.reference}</TableCell>
                  <TableCell>{article.name}</TableCell>
                  <TableCell>{article.category}</TableCell>
                  <TableCell>{article.supplier}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      {article.currentStock}
                      {article.currentStock <= article.minStock && (
                        <AlertTriangle className="h-4 w-4 text-orange-500 ml-2" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{article.minStock}</TableCell>
                  <TableCell>€{article.price}</TableCell>
                  <TableCell>{getStatusBadge(article.status, article.currentStock, article.minStock)}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
