"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Settings, Bell, Shield, Database, Save, Download, Upload, Globe, Lock, Key, AlertTriangle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    // Paramètres généraux
    organizationName: "Projet SWEDD+",
    organizationEmail: "contact@swedd.org",
    defaultLanguage: "fr",
    timezone: "Africa/Ndjamena",

    // Paramètres de plaintes
    complaintNumberPrefix: "PLT",
    autoAssignment: true,
    defaultPriority: "normal",
    maxProcessingDays: 7,

    // Notifications
    emailNotifications: true,
    urgentAlerts: true,
    reminderNotifications: true,
    reportNotifications: false,

    // Sécurité
    sessionTimeout: 30,
    passwordMinLength: 8,
    twoFactorAuth: false,
    confidentialAccess: true,

    // Sauvegarde
    autoBackup: true,
    backupFrequency: "daily",
    retentionPeriod: 365,
  })

  const handleSave = () => {
    console.log("Paramètres sauvegardés:", settings)
    // Ici on sauvegarderait les paramètres
  }

  const handleExport = () => {
    console.log("Export des données...")
    // Logique d'export
  }

  const handleImport = () => {
    console.log("Import des données...")
    // Logique d'import
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Configuration du système</h1>
        <p className="text-gray-600 mt-2">Paramètres globaux de la plateforme SWEDD+</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Paramètres généraux */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Paramètres généraux
            </CardTitle>
            <CardDescription>Configuration de base de l'organisation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="organizationName">Nom de l'organisation</Label>
              <Input
                id="organizationName"
                value={settings.organizationName}
                onChange={(e) => setSettings({ ...settings, organizationName: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="organizationEmail">Email de contact</Label>
              <Input
                id="organizationEmail"
                type="email"
                value={settings.organizationEmail}
                onChange={(e) => setSettings({ ...settings, organizationEmail: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="defaultLanguage">Langue par défaut</Label>
              <Select
                value={settings.defaultLanguage}
                onValueChange={(value) => setSettings({ ...settings, defaultLanguage: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="ar">العربية (Arabe)</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="timezone">Fuseau horaire</Label>
              <Select
                value={settings.timezone}
                onValueChange={(value) => setSettings({ ...settings, timezone: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Africa/Ndjamena">N'Djamena (UTC+1)</SelectItem>
                  <SelectItem value="Africa/Bangui">Bangui (UTC+1)</SelectItem>
                  <SelectItem value="Africa/Cairo">Le Caire (UTC+2)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Paramètres des plaintes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Gestion des plaintes
            </CardTitle>
            <CardDescription>Configuration du processus de traitement</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="complaintNumberPrefix">Préfixe des numéros de plainte</Label>
              <Input
                id="complaintNumberPrefix"
                value={settings.complaintNumberPrefix}
                onChange={(e) => setSettings({ ...settings, complaintNumberPrefix: e.target.value })}
                placeholder="Ex: PLT, SWEDD, etc."
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Attribution automatique</Label>
                <p className="text-sm text-gray-600">Assigner automatiquement les plaintes</p>
              </div>
              <Switch
                checked={settings.autoAssignment}
                onCheckedChange={(checked) => setSettings({ ...settings, autoAssignment: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="defaultPriority">Priorité par défaut</Label>
              <Select
                value={settings.defaultPriority}
                onValueChange={(value) => setSettings({ ...settings, defaultPriority: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Faible</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="high">Élevée</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxProcessingDays">Délai maximum de traitement (jours)</Label>
              <Input
                id="maxProcessingDays"
                type="number"
                value={settings.maxProcessingDays}
                onChange={(e) => setSettings({ ...settings, maxProcessingDays: Number.parseInt(e.target.value) })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bell className="h-5 w-5 mr-2" />
              Notifications
            </CardTitle>
            <CardDescription>Gestion des alertes et notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Notifications par email</Label>
                <p className="text-sm text-gray-600">Envoyer les notifications par email</p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Alertes urgentes</Label>
                <p className="text-sm text-gray-600">Notifications immédiates pour les cas urgents</p>
              </div>
              <Switch
                checked={settings.urgentAlerts}
                onCheckedChange={(checked) => setSettings({ ...settings, urgentAlerts: checked })}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Rappels de traitement</Label>
                <p className="text-sm text-gray-600">Rappels pour les délais de traitement</p>
              </div>
              <Switch
                checked={settings.reminderNotifications}
                onCheckedChange={(checked) => setSettings({ ...settings, reminderNotifications: checked })}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Rapports automatiques</Label>
                <p className="text-sm text-gray-600">Envoi automatique des rapports périodiques</p>
              </div>
              <Switch
                checked={settings.reportNotifications}
                onCheckedChange={(checked) => setSettings({ ...settings, reportNotifications: checked })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sécurité et confidentialité */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Sécurité et confidentialité
            </CardTitle>
            <CardDescription>Paramètres de sécurité et protection des données</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Délai d'expiration de session (minutes)</Label>
              <Input
                id="sessionTimeout"
                type="number"
                value={settings.sessionTimeout}
                onChange={(e) => setSettings({ ...settings, sessionTimeout: Number.parseInt(e.target.value) })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="passwordMinLength">Longueur minimale des mots de passe</Label>
              <Input
                id="passwordMinLength"
                type="number"
                value={settings.passwordMinLength}
                onChange={(e) => setSettings({ ...settings, passwordMinLength: Number.parseInt(e.target.value) })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="flex items-center">
                  <Key className="h-4 w-4 mr-1" />
                  Authentification à deux facteurs
                </Label>
                <p className="text-sm text-gray-600">Sécurité renforcée pour tous les comptes</p>
              </div>
              <Switch
                checked={settings.twoFactorAuth}
                onCheckedChange={(checked) => setSettings({ ...settings, twoFactorAuth: checked })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="flex items-center">
                  <Lock className="h-4 w-4 mr-1" />
                  Accès restreint catégories confidentielles
                </Label>
                <p className="text-sm text-gray-600">Catégories 5 et 6 limitées au coordinateur</p>
              </div>
              <Switch
                checked={settings.confidentialAccess}
                onCheckedChange={(checked) => setSettings({ ...settings, confidentialAccess: checked })}
              />
            </div>

            <div className="p-3 bg-orange-50 border border-orange-200 rounded-md">
              <div className="flex items-start space-x-2">
                <AlertTriangle className="h-4 w-4 text-orange-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-orange-800">Confidentialité renforcée</p>
                  <p className="text-xs text-orange-700">
                    Les plaintes de catégories 5 (Violence) et 6 (Exploitation) sont automatiquement restreintes au
                    coordinateur national uniquement.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sauvegarde et données */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="h-5 w-5 mr-2" />
            Sauvegarde et gestion des données
          </CardTitle>
          <CardDescription>Configuration des sauvegardes et archivage</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Sauvegarde automatique</Label>
                <p className="text-sm text-gray-600">Sauvegarde automatique quotidienne</p>
              </div>
              <Switch
                checked={settings.autoBackup}
                onCheckedChange={(checked) => setSettings({ ...settings, autoBackup: checked })}
              />
            </div>

            {settings.autoBackup && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="backupFrequency">Fréquence de sauvegarde</Label>
                  <Select
                    value={settings.backupFrequency}
                    onValueChange={(value) => setSettings({ ...settings, backupFrequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Quotidienne</SelectItem>
                      <SelectItem value="weekly">Hebdomadaire</SelectItem>
                      <SelectItem value="monthly">Mensuelle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="retentionPeriod">Période de rétention (jours)</Label>
                  <Input
                    id="retentionPeriod"
                    type="number"
                    value={settings.retentionPeriod}
                    onChange={(e) => setSettings({ ...settings, retentionPeriod: Number.parseInt(e.target.value) })}
                  />
                </div>
              </>
            )}
          </div>

          <Separator />

          <div className="space-y-4">
            <Label>Actions de gestion des données</Label>
            <div className="flex space-x-4">
              <Button variant="outline" onClick={handleExport} className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Exporter les données
              </Button>
              <Button variant="outline" onClick={handleImport} className="flex-1">
                <Upload className="h-4 w-4 mr-2" />
                Importer des données
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Dernière sauvegarde</h4>
                <p className="text-sm text-gray-600">15/01/2024 à 03:00</p>
                <Badge className="bg-green-100 text-green-800 mt-2">Succès</Badge>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Taille de la base</h4>
                <p className="text-sm text-gray-600">247 MB</p>
                <Badge variant="outline" className="mt-2">
                  Normal
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions système */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="h-5 w-5 mr-2" />
            Actions système
          </CardTitle>
          <CardDescription>Maintenance et actions administratives</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <Database className="h-6 w-6" />
              <span>Nettoyer les logs</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <Shield className="h-6 w-6" />
              <span>Audit de sécurité</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <Download className="h-6 w-6" />
              <span>Rapport système</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <Key className="h-6 w-6" />
              <span>Réinitialiser sessions</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bouton de sauvegarde principal */}
      <div className="flex justify-end space-x-4">
        <Button variant="outline">Réinitialiser les paramètres</Button>
        <Button onClick={handleSave} className="min-w-48">
          <Save className="h-4 w-4 mr-2" />
          Sauvegarder la configuration
        </Button>
      </div>
    </div>
  )
}
