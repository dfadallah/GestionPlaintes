"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  MessageSquare,
  Clock,
  CheckCircle,
  AlertTriangle,
  Users,
  MapPin,
  TrendingUp,
  FileText,
  Eye,
  Plus,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"

// Données simulées pour le tableau de bord
const stats = [
  {
    title: "Total des plaintes",
    value: "1,247",
    change: "+23 cette semaine",
    trend: "up",
    icon: MessageSquare,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
  {
    title: "En cours de traitement",
    value: "156",
    change: "12% du total",
    trend: "neutral",
    icon: Clock,
    color: "text-orange-600",
    bgColor: "bg-orange-50",
  },
  {
    title: "Résolues ce mois",
    value: "324",
    change: "+18% vs mois dernier",
    trend: "up",
    icon: CheckCircle,
    color: "text-green-600",
    bgColor: "bg-green-50",
  },
  {
    title: "Délai moyen",
    value: "5.2 jours",
    change: "-1.3 jours vs cible",
    trend: "up",
    icon: TrendingUp,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
  },
]

const urgentComplaints = [
  {
    id: "PLT-2024-0156",
    category: "Catégorie 5 - Violence",
    location: "N'Djamena, Tchad",
    daysOpen: 8,
    priority: "Très urgent",
    confidentiality: "Restreint",
  },
  {
    id: "PLT-2024-0148",
    category: "Catégorie 6 - Exploitation",
    location: "Sarh, Tchad",
    daysOpen: 6,
    priority: "Urgent",
    confidentiality: "Restreint",
  },
  {
    id: "PLT-2024-0142",
    category: "Catégorie 2 - Discrimination",
    location: "Moundou, Tchad",
    daysOpen: 12,
    priority: "Important",
    confidentiality: "Standard",
  },
]

const recentActivity = [
  {
    action: "Nouvelle plainte enregistrée",
    complaint: "PLT-2024-0159",
    user: "Réceptionniste Aisha",
    time: "Il y a 15 min",
  },
  { action: "Plainte assignée", complaint: "PLT-2024-0158", user: "Agent Moussa", time: "Il y a 1h" },
  { action: "Résolution complétée", complaint: "PLT-2024-0145", user: "Agent Fatima", time: "Il y a 2h" },
  { action: "Plainte clôturée", complaint: "PLT-2024-0133", user: "Coordinateur Ahmed", time: "Il y a 3h" },
]

const channelStats = [
  { channel: "Téléphone", count: 456, percentage: 36.6 },
  { channel: "En personne", count: 378, percentage: 30.3 },
  { channel: "Email", count: 234, percentage: 18.8 },
  { channel: "Courrier", count: 123, percentage: 9.9 },
  { channel: "Réseaux sociaux", count: 56, percentage: 4.4 },
]

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tableau de bord SWEDD+</h1>
          <p className="text-gray-600 mt-2">Vue d'ensemble du système de gestion des plaintes</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Rapport hebdomadaire
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Nouvelle plainte
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center text-xs text-gray-600 mt-1">
                <span className={stat.trend === "up" ? "text-green-600" : "text-gray-600"}>{stat.change}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Plaintes urgentes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
              Plaintes urgentes à traiter
            </CardTitle>
            <CardDescription>Plaintes nécessitant une attention immédiate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {urgentComplaints.map((complaint, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-gray-900">{complaint.id}</p>
                      <p className="text-sm text-gray-600">{complaint.category}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Badge
                        variant={complaint.priority === "Très urgent" ? "destructive" : "secondary"}
                        className={complaint.priority === "Urgent" ? "bg-orange-100 text-orange-800" : ""}
                      >
                        {complaint.priority}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={complaint.confidentiality === "Restreint" ? "border-red-200 text-red-700" : ""}
                      >
                        {complaint.confidentiality}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {complaint.location}
                    </div>
                    <span>{complaint.daysOpen} jours ouverts</span>
                  </div>
                </div>
              ))}
            </div>
            <Button className="w-full mt-4" variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              Voir toutes les plaintes urgentes
            </Button>
          </CardContent>
        </Card>

        {/* Activité récente */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="h-5 w-5 text-blue-600 mr-2" />
              Activité récente
            </CardTitle>
            <CardDescription>Dernières actions sur les plaintes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                  <div className="h-2 w-2 bg-blue-600 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600">
                      {activity.complaint} - {activity.user}
                    </p>
                  </div>
                  <span className="text-xs text-gray-500">{activity.time}</span>
                </div>
              ))}
            </div>
            <Button className="w-full mt-4" variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              Voir tout l'historique
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Statistiques par canal */}
      <Card>
        <CardHeader>
          <CardTitle>Canaux de réception des plaintes</CardTitle>
          <CardDescription>Répartition des plaintes par mode de communication</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {channelStats.map((channel, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{channel.channel}</span>
                  <span className="text-sm text-gray-600">
                    {channel.count} ({channel.percentage}%)
                  </span>
                </div>
                <Progress value={channel.percentage} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Actions rapides */}
      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
          <CardDescription>Accès direct aux fonctionnalités principales</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button className="h-20 flex-col space-y-2" variant="outline">
              <Plus className="h-6 w-6" />
              <span>Nouvelle plainte</span>
            </Button>
            <Button className="h-20 flex-col space-y-2" variant="outline">
              <Eye className="h-6 w-6" />
              <span>Suivi plaintes</span>
            </Button>
            <Button className="h-20 flex-col space-y-2" variant="outline">
              <FileText className="h-6 w-6" />
              <span>Générer rapport</span>
            </Button>
            <Button className="h-20 flex-col space-y-2" variant="outline">
              <Users className="h-6 w-6" />
              <span>Gestion utilisateurs</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
