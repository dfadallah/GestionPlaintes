"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, Eye, Users, Shield, UserCheck, Key, Mail, Phone } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Données simulées des utilisateurs
const users = [
  {
    id: 1,
    name: "Ahmed Moussa",
    email: "ahmed.moussa@swedd.org",
    role: "Coordinateur national",
    status: "Actif",
    lastLogin: "2024-01-15 14:30",
    createdAt: "2023-06-15",
    phone: "+235 99 88 77 66",
    permissions: ["Accès complet", "Catégories confidentielles", "Gestion utilisateurs", "Rapports"],
  },
  {
    id: 2,
    name: "Fatima Hassan",
    email: "fatima.hassan@swedd.org",
    role: "Agent de traitement",
    status: "Actif",
    lastLogin: "2024-01-15 11:15",
    createdAt: "2023-08-20",
    phone: "+235 98 77 66 55",
    permissions: ["Traitement plaintes", "Enquêtes", "Résolutions"],
  },
  {
    id: 3,
    name: "Aisha Omar",
    email: "aisha.omar@swedd.org",
    role: "Réceptionniste",
    status: "Actif",
    lastLogin: "2024-01-14 16:45",
    createdAt: "2023-09-10",
    phone: "+235 97 66 55 44",
    permissions: ["Enregistrement plaintes", "Assignation initiale"],
  },
  {
    id: 4,
    name: "Khadija Abdel",
    email: "khadija.abdel@swedd.org",
    role: "Observateur",
    status: "Actif",
    lastLogin: "2024-01-10 09:20",
    createdAt: "2023-11-05",
    phone: "+235 96 55 44 33",
    permissions: ["Consultation", "Rapports"],
  },
  {
    id: 5,
    name: "Mariam Souleman",
    email: "mariam.souleman@swedd.org",
    role: "Administrateur",
    status: "Inactif",
    lastLogin: "2024-01-05 08:15",
    createdAt: "2023-07-20",
    phone: "+235 95 44 33 22",
    permissions: ["Administration système", "Configuration", "Sauvegardes"],
  },
]

const roles = [
  {
    value: "admin",
    label: "Administrateur",
    description: "Accès complet au système",
    permissions: ["Administration système", "Configuration", "Sauvegardes", "Gestion utilisateurs"],
  },
  {
    value: "coordinator",
    label: "Coordinateur national",
    description: "Supervision et accès aux données confidentielles",
    permissions: ["Accès complet", "Catégories confidentielles", "Gestion utilisateurs", "Rapports"],
  },
  {
    value: "agent",
    label: "Agent de traitement",
    description: "Traitement et résolution des plaintes",
    permissions: ["Traitement plaintes", "Enquêtes", "Résolutions"],
  },
  {
    value: "receptionist",
    label: "Réceptionniste",
    description: "Enregistrement et assignation des plaintes",
    permissions: ["Enregistrement plaintes", "Assignation initiale"],
  },
  {
    value: "observer",
    label: "Observateur",
    description: "Consultation et rapports en lecture seule",
    permissions: ["Consultation", "Rapports"],
  },
]

export default function UsersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRole, setSelectedRole] = useState("Tous les rôles")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    phone: "",
    role: "",
    password: "",
  })

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole =
      selectedRole === "Tous les rôles" || user.role.toLowerCase().includes(selectedRole.toLowerCase())
    return matchesSearch && matchesRole
  })

  const getRoleBadge = (role: string) => {
    const roleConfig = {
      "Coordinateur national": { color: "bg-purple-100 text-purple-800", icon: Shield },
      Administrateur: { color: "bg-red-100 text-red-800", icon: Key },
      "Agent de traitement": { color: "bg-blue-100 text-blue-800", icon: UserCheck },
      Réceptionniste: { color: "bg-green-100 text-green-800", icon: Users },
      Observateur: { color: "bg-gray-100 text-gray-800", icon: Eye },
    }

    const config = roleConfig[role as keyof typeof roleConfig] || roleConfig["Observateur"]
    const IconComponent = config.icon

    return (
      <Badge className={config.color}>
        <IconComponent className="h-3 w-3 mr-1" />
        {role}
      </Badge>
    )
  }

  const getStatusBadge = (status: string) => {
    if (status === "Actif") {
      return <Badge className="bg-green-100 text-green-800">Actif</Badge>
    } else {
      return <Badge variant="secondary">Inactif</Badge>
    }
  }

  const handleAddUser = () => {
    console.log("Nouvel utilisateur:", newUser)
    setIsDialogOpen(false)
    setNewUser({
      name: "",
      email: "",
      phone: "",
      role: "",
      password: "",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestion des utilisateurs</h1>
          <p className="text-gray-600 mt-2">Administration des comptes et permissions</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nouvel utilisateur
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Créer un nouvel utilisateur</DialogTitle>
              <DialogDescription>
                Ajoutez un nouveau membre à l'équipe SWEDD+ avec les permissions appropriées.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Nom complet
                </Label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  className="col-span-3"
                  placeholder="Prénom et nom"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="col-span-3"
                  placeholder="nom@swedd.org"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                  Téléphone
                </Label>
                <Input
                  id="phone"
                  value={newUser.phone}
                  onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                  className="col-span-3"
                  placeholder="+235 XX XX XX XX"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role" className="text-right">
                  Rôle
                </Label>
                <Select onValueChange={(value) => setNewUser({ ...newUser, role: value })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Sélectionner un rôle" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((role) => (
                      <SelectItem key={role.value} value={role.value}>
                        <div className="flex flex-col">
                          <span className="font-medium">{role.label}</span>
                          <span className="text-xs text-gray-500">{role.description}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="password" className="text-right">
                  Mot de passe
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  className="col-span-3"
                  placeholder="Mot de passe temporaire"
                />
              </div>
              {newUser.role && (
                <div className="col-span-4 p-3 bg-blue-50 rounded-md">
                  <Label className="text-sm font-medium">Permissions accordées :</Label>
                  <div className="mt-2 space-y-1">
                    {roles
                      .find((r) => r.value === newUser.role)
                      ?.permissions.map((permission) => (
                        <div key={permission} className="flex items-center text-sm text-gray-600">
                          <Shield className="h-3 w-3 mr-2" />
                          {permission}
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddUser}>
                Créer l'utilisateur
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total utilisateurs</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
            <p className="text-xs text-gray-600">Comptes actifs et inactifs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilisateurs actifs</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.filter((u) => u.status === "Actif").length}</div>
            <p className="text-xs text-gray-600">
              {Math.round((users.filter((u) => u.status === "Actif").length / users.length) * 100)}% du total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Agents de traitement</CardTitle>
            <Shield className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.filter((u) => u.role === "Agent de traitement").length}</div>
            <p className="text-xs text-gray-600">Personnel opérationnel</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Connexions aujourd'hui</CardTitle>
            <UserCheck className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-gray-600">Sessions actives</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtres et recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Rechercher par nom, email ou téléphone..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger className="w-full md:w-64">
                <SelectValue placeholder="Tous les rôles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les rôles</SelectItem>
                {roles.map((role) => (
                  <SelectItem key={role.value} value={role.label}>
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des utilisateurs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Équipe SWEDD+ ({filteredUsers.length})
          </CardTitle>
          <CardDescription>Liste des utilisateurs autorisés à accéder au système</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Rôle</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Dernière connexion</TableHead>
                <TableHead>Permissions</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="font-medium">{user.name}</div>
                    <div className="text-xs text-gray-500">Créé le {user.createdAt}</div>
                  </TableCell>

                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center text-sm">
                        <Mail className="h-3 w-3 mr-1 text-gray-400" />
                        {user.email}
                      </div>
                      <div className="flex items-center text-sm">
                        <Phone className="h-3 w-3 mr-1 text-gray-400" />
                        {user.phone}
                      </div>
                    </div>
                  </TableCell>

                  <TableCell>{getRoleBadge(user.role)}</TableCell>

                  <TableCell>{getStatusBadge(user.status)}</TableCell>

                  <TableCell>
                    <div className="text-sm">{user.lastLogin}</div>
                  </TableCell>

                  <TableCell>
                    <div className="space-y-1">
                      {user.permissions.slice(0, 2).map((permission, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {permission}
                        </Badge>
                      ))}
                      {user.permissions.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{user.permissions.length - 2} autres
                        </Badge>
                      )}
                    </div>
                  </TableCell>

                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
