"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Filter, ArrowUpDown, TrendingUp, TrendingDown, Calendar, Download } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

// Données simulées
const movements = [
  {
    id: 1,
    date: "2024-01-15",
    time: "14:30",
    type: "Entrée",
    article: "Ordinateur portable Dell Latitude",
    reference: "ORD-001",
    quantity: 10,
    reason: "Commande fournisseur",
    user: "Marie Dupont",
    supplier: "Dell France",
  },
  {
    id: 2,
    date: "2024-01-15",
    time: "11:15",
    type: "Sortie",
    article: "Chaise de bureau ergonomique",
    reference: "CHA-002",
    quantity: 3,
    reason: "Attribution service RH",
    user: "Jean Martin",
    supplier: "-",
  },
  {
    id: 3,
    date: "2024-01-14",
    time: "16:45",
    type: "Entrée",
    article: "Papier A4 80g",
    reference: "PAP-004",
    quantity: 100,
    reason: "Réapprovisionnement",
    user: "Pierre Durand",
    supplier: "Clairefontaine",
  },
  {
    id: 4,
    date: "2024-01-14",
    time: "09:20",
    type: "Sortie",
    article: "Imprimante laser HP",
    reference: "IMP-003",
    quantity: 2,
    reason: "Installation bureau étage 2",
    user: "Sophie Bernard",
    supplier: "-",
  },
]

const articles = [
  { reference: "ORD-001", name: "Ordinateur portable Dell Latitude" },
  { reference: "CHA-002", name: "Chaise de bureau ergonomique" },
  { reference: "PAP-004", name: "Papier A4 80g" },
  { reference: "IMP-003", name: "Imprimante laser HP" },
]

export default function MovementsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedType, setSelectedType] = useState("Entrée") // Updated default value
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newMovement, setNewMovement] = useState({
    type: "Entrée", // Updated default value
    article: "",
    quantity: 0,
    reason: "",
    supplier: "",
  })

  const filteredMovements = movements.filter((movement) => {
    const matchesSearch =
      movement.article.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.user.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = !selectedType || movement.type === selectedType
    return matchesSearch && matchesType
  })

  const getTypeBadge = (type: string) => {
    if (type === "Entrée") {
      return (
        <Badge className="bg-green-100 text-green-800">
          <TrendingUp className="h-3 w-3 mr-1" />
          Entrée
        </Badge>
      )
    } else {
      return (
        <Badge className="bg-orange-100 text-orange-800">
          <TrendingDown className="h-3 w-3 mr-1" />
          Sortie
        </Badge>
      )
    }
  }

  const handleAddMovement = () => {
    // Logique d'ajout de mouvement
    console.log("Nouveau mouvement:", newMovement)
    setIsDialogOpen(false)
    setNewMovement({
      type: "Entrée", // Updated default value
      article: "",
      quantity: 0,
      reason: "",
      supplier: "",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mouvements de stock</h1>
          <p className="text-gray-600 mt-2">Suivi des entrées et sorties de stock</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exporter
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nouveau mouvement
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Ajouter un mouvement de stock</DialogTitle>
                <DialogDescription>Enregistrez une entrée ou sortie de stock.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="type" className="text-right">
                    Type
                  </Label>
                  <Select onValueChange={(value) => setNewMovement({ ...newMovement, type: value })}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Sélectionner le type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Entrée">Entrée</SelectItem>
                      <SelectItem value="Sortie">Sortie</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="article" className="text-right">
                    Article
                  </Label>
                  <Select onValueChange={(value) => setNewMovement({ ...newMovement, article: value })}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Sélectionner un article" />
                    </SelectTrigger>
                    <SelectContent>
                      {articles.map((article) => (
                        <SelectItem key={article.reference} value={article.reference}>
                          {article.reference} - {article.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="quantity" className="text-right">
                    Quantité
                  </Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={newMovement.quantity}
                    onChange={(e) => setNewMovement({ ...newMovement, quantity: Number.parseInt(e.target.value) })}
                    className="col-span-3"
                  />
                </div>
                {newMovement.type === "Entrée" && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="supplier" className="text-right">
                      Fournisseur
                    </Label>
                    <Input
                      id="supplier"
                      value={newMovement.supplier}
                      onChange={(e) => setNewMovement({ ...newMovement, supplier: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                )}
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="reason" className="text-right">
                    Motif
                  </Label>
                  <Textarea
                    id="reason"
                    value={newMovement.reason}
                    onChange={(e) => setNewMovement({ ...newMovement, reason: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddMovement}>
                  Enregistrer le mouvement
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mouvements aujourd'hui</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-gray-600">+3 vs hier</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Entrées ce mois</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-gray-600">+12% vs mois dernier</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sorties ce mois</CardTitle>
            <TrendingDown className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89</div>
            <p className="text-xs text-gray-600">-5% vs mois dernier</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtres et recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Rechercher par article, référence ou utilisateur..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Tous les types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Entrée">Entrées</SelectItem>
                <SelectItem value="Sortie">Sorties</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Période
            </Button>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filtres
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des mouvements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ArrowUpDown className="h-5 w-5 mr-2" />
            Historique des mouvements ({filteredMovements.length})
          </CardTitle>
          <CardDescription>Liste chronologique de tous les mouvements de stock</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date/Heure</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Article</TableHead>
                <TableHead>Référence</TableHead>
                <TableHead>Quantité</TableHead>
                <TableHead>Motif</TableHead>
                <TableHead>Utilisateur</TableHead>
                <TableHead>Fournisseur</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMovements.map((movement) => (
                <TableRow key={movement.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{movement.date}</div>
                      <div className="text-sm text-gray-600">{movement.time}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getTypeBadge(movement.type)}</TableCell>
                  <TableCell className="font-medium">{movement.article}</TableCell>
                  <TableCell>{movement.reference}</TableCell>
                  <TableCell>
                    <span
                      className={`font-medium ${movement.type === "Entrée" ? "text-green-600" : "text-orange-600"}`}
                    >
                      {movement.type === "Entrée" ? "+" : "-"}
                      {movement.quantity}
                    </span>
                  </TableCell>
                  <TableCell>{movement.reason}</TableCell>
                  <TableCell>{movement.user}</TableCell>
                  <TableCell>{movement.supplier}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
