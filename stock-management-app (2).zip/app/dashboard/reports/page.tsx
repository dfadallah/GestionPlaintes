"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FileText, Download, BarChart3, PieChart, TrendingUp, Filter, MapPin, Users, Clock } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

// Données simulées pour les rapports
const reportData = {
  totalComplaints: 1247,
  receivable: 1180,
  rejected: 67,
  treated: 987,
  averageProcessingTime: 5.2,
  channelStats: [
    { channel: "Téléphone", count: 456, percentage: 36.6 },
    { channel: "En personne", count: 378, percentage: 30.3 },
    { channel: "Email", count: 234, percentage: 18.8 },
    { channel: "Courrier", count: 123, percentage: 9.9 },
    { channel: "Réseaux sociaux", count: 56, percentage: 4.4 },
  ],
  categoryStats: [
    { category: "Catégorie 1 - Mauvaise qualité", count: 345, percentage: 27.7 },
    { category: "Catégorie 2 - Discrimination", count: 289, percentage: 23.2 },
    { category: "Catégorie 3 - Mauvaise gestion", count: 234, percentage: 18.8 },
    { category: "Catégorie 4 - Corruption", count: 178, percentage: 14.3 },
    { category: "Catégorie 5 - Violence", count: 123, percentage: 9.9 },
    { category: "Catégorie 6 - Exploitation", count: 78, percentage: 6.3 },
  ],
  geographicStats: [
    { location: "N'Djamena", count: 423, percentage: 33.9 },
    { location: "Sarh", count: 189, percentage: 15.2 },
    { location: "Moundou", count: 156, percentage: 12.5 },
    { location: "Abéché", count: 134, percentage: 10.7 },
    { location: "Doba", count: 98, percentage: 7.9 },
    { location: "Autres", count: 247, percentage: 19.8 },
  ],
  recourseStats: {
    total: 89,
    judicial: 23,
    administrative: 45,
    mediation: 21,
  },
}

export default function ReportsPage() {
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    location: "all",
    category: "all",
    status: "all",
  })

  const handleExportPDF = () => {
    console.log("Export PDF...")
    // Ici on générerait et téléchargerait le PDF
  }

  const handleExportExcel = () => {
    console.log("Export Excel...")
    // Ici on générerait et téléchargerait l'Excel
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Rapports et Analyses</h1>
          <p className="text-gray-600 mt-2">Tableaux de bord statistiques et rapports détaillés</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleExportExcel}>
            <Download className="h-4 w-4 mr-2" />
            Export Excel
          </Button>
          <Button onClick={handleExportPDF}>
            <FileText className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {/* Filtres */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filtres de rapport
          </CardTitle>
          <CardDescription>Personnalisez votre rapport selon vos critères</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Date de début</Label>
              <Input
                id="startDate"
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Date de fin</Label>
              <Input
                id="endDate"
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Zone géographique</Label>
              <Select value={filters.location} onValueChange={(value) => setFilters({ ...filters, location: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les zones" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes les zones</SelectItem>
                  <SelectItem value="ndjamena">N'Djamena</SelectItem>
                  <SelectItem value="sarh">Sarh</SelectItem>
                  <SelectItem value="moundou">Moundou</SelectItem>
                  <SelectItem value="abeche">Abéché</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Catégorie</Label>
              <Select value={filters.category} onValueChange={(value) => setFilters({ ...filters, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les catégories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Toutes les catégories</SelectItem>
                  <SelectItem value="cat1">Catégorie 1</SelectItem>
                  <SelectItem value="cat2">Catégorie 2</SelectItem>
                  <SelectItem value="cat3">Catégorie 3</SelectItem>
                  <SelectItem value="cat4">Catégorie 4</SelectItem>
                  <SelectItem value="cat5">Catégorie 5</SelectItem>
                  <SelectItem value="cat6">Catégorie 6</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Statut</Label>
              <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les statuts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les statuts</SelectItem>
                  <SelectItem value="treated">Traitées</SelectItem>
                  <SelectItem value="pending">En cours</SelectItem>
                  <SelectItem value="closed">Clôturées</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Indicateurs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total plaintes reçues</CardTitle>
            <BarChart3 className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reportData.totalComplaints.toLocaleString()}</div>
            <p className="text-xs text-gray-600">Toutes périodes confondues</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Plaintes recevables</CardTitle>
            <PieChart className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reportData.receivable.toLocaleString()}</div>
            <p className="text-xs text-gray-600">
              {((reportData.receivable / reportData.totalComplaints) * 100).toFixed(1)}% du total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Plaintes traitées</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reportData.treated.toLocaleString()}</div>
            <p className="text-xs text-gray-600">
              {((reportData.treated / reportData.receivable) * 100).toFixed(1)}% des recevables
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Délai moyen</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reportData.averageProcessingTime} jours</div>
            <p className="text-xs text-gray-600">Temps de traitement moyen</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Canaux de réception */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Canaux de réception
            </CardTitle>
            <CardDescription>Répartition des plaintes par mode de communication</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {reportData.channelStats.map((channel, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{channel.channel}</span>
                  <span className="text-sm text-gray-600">
                    {channel.count} ({channel.percentage}%)
                  </span>
                </div>
                <Progress value={channel.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Catégories de plaintes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 mr-2" />
              Catégories de plaintes
            </CardTitle>
            <CardDescription>Distribution par type de plainte</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {reportData.categoryStats.map((category, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{category.category}</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">{category.count}</span>
                    <Badge variant="outline">{category.percentage}%</Badge>
                  </div>
                </div>
                <Progress value={category.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Répartition géographique */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="h-5 w-5 mr-2" />
              Répartition géographique
            </CardTitle>
            <CardDescription>Plaintes par zone géographique</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {reportData.geographicStats.map((location, index) => (
              <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <span className="font-medium">{location.location}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm">{location.count}</span>
                  <Badge variant="outline">{location.percentage}%</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recours et procédures judiciaires */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Recours et procédures
            </CardTitle>
            <CardDescription>Statistiques des recours engagés</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600">{reportData.recourseStats.total}</div>
              <div className="text-sm text-gray-600">Total des recours</div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <span className="font-medium">Procédures judiciaires</span>
                <Badge className="bg-red-100 text-red-800">{reportData.recourseStats.judicial}</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <span className="font-medium">Recours administratifs</span>
                <Badge className="bg-orange-100 text-orange-800">{reportData.recourseStats.administrative}</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <span className="font-medium">Médiations</span>
                <Badge className="bg-green-100 text-green-800">{reportData.recourseStats.mediation}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Actions de rapport */}
      <Card>
        <CardHeader>
          <CardTitle>Génération de rapports</CardTitle>
          <CardDescription>Créez des rapports personnalisés selon vos besoins</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <FileText className="h-6 w-6" />
              <span>Rapport mensuel</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <BarChart3 className="h-6 w-6" />
              <span>Analyse de tendances</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col space-y-2">
              <MapPin className="h-6 w-6" />
              <span>Rapport géographique</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
