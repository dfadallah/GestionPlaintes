"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle,
  Clock,
  User,
  Calendar,
  FileText,
  Send,
  Save,
  AlertTriangle,
  MessageCircle,
  Phone,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

// Données simulées pour la plainte en cours de traitement
const complaintData = {
  id: "PLT-2024-0158",
  date: "2024-01-14",
  complainant: "Fatima Ahmed",
  category: "Catégorie 2 - Discrimination",
  location: "N'Djamena, Tchad",
  description:
    "Discrimination lors de l'accès aux services de santé reproductive dans le centre de santé local. Le personnel refuse de servir les jeunes femmes non mariées.",
  status: "En cours",
  priority: "Urgent",
  assignedTo: "Agent Moussa",
  daysOpen: 4,
  confidential: false,
  channel: "Téléphone",
  complainantPhone: "+235 99 88 77 66",
  complainantConsent: true,
}

export default function ProcessingPage() {
  const [selectedComplaint] = useState(complaintData)
  const [processing, setProcessing] = useState({
    investigation: "",
    findings: "",
    proposedSolution: "",
    communicationMode: "",
    responseDate: "",
    followUpRequired: false,
    resolution: "",
    finalDecision: "",
  })

  const handleSubmitResolution = () => {
    console.log("Résolution soumise:", processing)
    // Ici on enverrait la résolution au serveur
  }

  const handleCloseComplaint = () => {
    console.log("Plainte clôturée")
    // Ici on marquerait la plainte comme clôturée
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Traitement des plaintes</h1>
        <p className="text-gray-600 mt-2">Interface de traitement et résolution des plaintes</p>
      </div>

      {/* Informations de la plainte */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Plainte {selectedComplaint.id}
            </span>
            <div className="flex space-x-2">
              <Badge className="bg-orange-100 text-orange-800">
                <Clock className="h-3 w-3 mr-1" />
                {selectedComplaint.status}
              </Badge>
              <Badge variant="destructive">{selectedComplaint.priority}</Badge>
            </div>
          </CardTitle>
          <CardDescription>
            Déposée le {selectedComplaint.date} - {selectedComplaint.daysOpen} jours ouverts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-600">Plaignant</Label>
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-gray-400" />
                <span>{selectedComplaint.complainant}</span>
                {selectedComplaint.complainantConsent && (
                  <Badge variant="outline" className="text-xs">
                    Contactable
                  </Badge>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-600">Localisation</Label>
              <div className="flex items-center space-x-2">
                <span>{selectedComplaint.location}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-600">Catégorie</Label>
              <div>{selectedComplaint.category}</div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-600">Canal de réception</Label>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-gray-400" />
                <span>{selectedComplaint.channel}</span>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-600">Description de la plainte</Label>
            <div className="p-3 bg-gray-50 rounded-md text-sm">{selectedComplaint.description}</div>
          </div>

          {selectedComplaint.complainantPhone && (
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-600">Contact plaignant</Label>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">{selectedComplaint.complainantPhone}</span>
                </div>
                <Button variant="outline" size="sm">
                  <Phone className="h-4 w-4 mr-1" />
                  Appeler
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Formulaire de traitement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Investigation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Investigation
            </CardTitle>
            <CardDescription>Enquête et analyse de la plainte</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="investigation">Description de l'enquête menée *</Label>
              <Textarea
                id="investigation"
                value={processing.investigation}
                onChange={(e) => setProcessing({ ...processing, investigation: e.target.value })}
                placeholder="Décrivez les étapes de l'enquête, les personnes rencontrées, les vérifications effectuées..."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="findings">Constats et conclusions *</Label>
              <Textarea
                id="findings"
                value={processing.findings}
                onChange={(e) => setProcessing({ ...processing, findings: e.target.value })}
                placeholder="Résumez vos constats et conclusions suite à l'enquête..."
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        {/* Solution proposée */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CheckCircle className="h-5 w-5 mr-2" />
              Solution et résolution
            </CardTitle>
            <CardDescription>Proposition de solution et mise en œuvre</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="proposedSolution">Solution proposée *</Label>
              <Textarea
                id="proposedSolution"
                value={processing.proposedSolution}
                onChange={(e) => setProcessing({ ...processing, proposedSolution: e.target.value })}
                placeholder="Décrivez la solution proposée pour résoudre la plainte..."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="resolution">Détail de la résolution</Label>
              <Textarea
                id="resolution"
                value={processing.resolution}
                onChange={(e) => setProcessing({ ...processing, resolution: e.target.value })}
                placeholder="Décrivez comment la solution a été mise en œuvre..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Communication avec le plaignant */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageCircle className="h-5 w-5 mr-2" />
            Communication au plaignant
          </CardTitle>
          <CardDescription>Retour d'information et suivi</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <Label>Mode de communication de la réponse *</Label>
              <RadioGroup
                value={processing.communicationMode}
                onValueChange={(value) => setProcessing({ ...processing, communicationMode: value })}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="phone" id="phone" />
                  <Label htmlFor="phone">Téléphone</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="inPerson" id="inPerson" />
                  <Label htmlFor="inPerson">En personne</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="email" id="email" />
                  <Label htmlFor="email">Email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="letter" id="letter" />
                  <Label htmlFor="letter">Courrier postal</Label>
                </div>
              </RadioGroup>
            </div>
            <div className="space-y-2">
              <Label htmlFor="responseDate">Date de réponse au plaignant</Label>
              <Input
                id="responseDate"
                type="date"
                value={processing.responseDate}
                onChange={(e) => setProcessing({ ...processing, responseDate: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Décision finale */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="h-5 w-5 mr-2" />
            Décision finale et clôture
          </CardTitle>
          <CardDescription>Finalisation du traitement de la plainte</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="finalDecision">Décision finale</Label>
            <Select
              value={processing.finalDecision}
              onValueChange={(value) => setProcessing({ ...processing, finalDecision: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner la décision finale" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="resolved">Plainte résolue - Satisfaisante</SelectItem>
                <SelectItem value="partiallyResolved">Plainte partiellement résolue</SelectItem>
                <SelectItem value="rejected">Plainte rejetée - Non fondée</SelectItem>
                <SelectItem value="transferred">Transférée vers autorité compétente</SelectItem>
                <SelectItem value="appeal">En attente de recours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex space-x-4">
        <Button onClick={handleSubmitResolution} className="flex-1">
          <Save className="h-4 w-4 mr-2" />
          Sauvegarder le traitement
        </Button>
        <Button variant="outline" onClick={handleSubmitResolution}>
          <Send className="h-4 w-4 mr-2" />
          Soumettre pour validation
        </Button>
        <Button variant="destructive" onClick={handleCloseComplaint}>
          <CheckCircle className="h-4 w-4 mr-2" />
          Clôturer la plainte
        </Button>
      </div>

      {/* Historique des actions */}
      <Card>
        <CardHeader>
          <CardTitle>Historique des actions</CardTitle>
          <CardDescription>Suivi chronologique de toutes les actions effectuées</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <div className="h-2 w-2 bg-blue-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Plainte assignée à Agent Moussa</p>
                <p className="text-xs text-gray-600">14/01/2024 10:30 - Par Réceptionniste Aisha</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <div className="h-2 w-2 bg-green-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Enquête initiée</p>
                <p className="text-xs text-gray-600">14/01/2024 14:15 - Par Agent Moussa</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 border rounded-lg">
              <div className="h-2 w-2 bg-orange-600 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Contact avec le plaignant</p>
                <p className="text-xs text-gray-600">15/01/2024 09:45 - Par Agent Moussa</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
