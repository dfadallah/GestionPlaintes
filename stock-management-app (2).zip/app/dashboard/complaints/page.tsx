"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Filter,
  Eye,
  Edit,
  MessageSquare,
  Calendar,
  User,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Données simulées des plaintes
const complaints = [
  {
    id: "PLT-2024-0159",
    date: "2024-01-15",
    complainant: "Fatima Ahmed",
    category: "Catégorie 2 - Discrimination",
    location: "N'Djamena, Tchad",
    status: "En cours",
    priority: "Normal",
    assignedTo: "Agent Moussa",
    daysOpen: 3,
    confidential: false,
    channel: "Téléphone",
  },
  {
    id: "PLT-2024-0158",
    date: "2024-01-14",
    complainant: "Anonyme",
    category: "Catégorie 5 - Violence",
    location: "Sarh, Tchad",
    status: "Assignée",
    priority: "Urgent",
    assignedTo: "Agent Fatima",
    daysOpen: 4,
    confidential: true,
    channel: "En personne",
  },
  {
    id: "PLT-2024-0157",
    date: "2024-01-13",
    complainant: "Aisha Hassan",
    category: "Catégorie 1 - Mauvaise qualité",
    location: "Moundou, Tchad",
    status: "Résolue",
    priority: "Normal",
    assignedTo: "Agent Ahmed",
    daysOpen: 5,
    confidential: false,
    channel: "Email",
  },
  {
    id: "PLT-2024-0156",
    date: "2024-01-12",
    complainant: "Khadija Omar",
    category: "Catégorie 6 - Exploitation",
    location: "Abéché, Tchad",
    status: "En recours",
    priority: "Très urgent",
    assignedTo: "Coordinateur Ahmed",
    daysOpen: 6,
    confidential: true,
    channel: "Via un tiers",
  },
  {
    id: "PLT-2024-0155",
    date: "2024-01-10",
    complainant: "Mariam Souleman",
    category: "Catégorie 3 - Mauvaise gestion",
    location: "Doba, Tchad",
    status: "Clôturée",
    priority: "Normal",
    assignedTo: "Agent Moussa",
    daysOpen: 8,
    confidential: false,
    channel: "Courrier",
  },
]

export default function ComplaintsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("Enregistrée")
  const [selectedCategory, setSelectedCategory] = useState("Catégorie 1")

  const filteredComplaints = complaints.filter((complaint) => {
    const matchesSearch =
      complaint.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.complainant.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.location.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = !selectedStatus || complaint.status === selectedStatus
    const matchesCategory = !selectedCategory || complaint.category.includes(selectedCategory)

    return matchesSearch && matchesStatus && matchesCategory
  })

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      Enregistrée: { color: "bg-blue-100 text-blue-800", icon: MessageSquare },
      Assignée: { color: "bg-yellow-100 text-yellow-800", icon: User },
      "En cours": { color: "bg-orange-100 text-orange-800", icon: Clock },
      Résolue: { color: "bg-green-100 text-green-800", icon: CheckCircle },
      "En recours": { color: "bg-purple-100 text-purple-800", icon: AlertTriangle },
      Clôturée: { color: "bg-gray-100 text-gray-800", icon: XCircle },
    }

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig["Enregistrée"]
    const IconComponent = config.icon

    return (
      <Badge className={config.color}>
        <IconComponent className="h-3 w-3 mr-1" />
        {status}
      </Badge>
    )
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "Très urgent":
        return <Badge variant="destructive">Très urgent</Badge>
      case "Urgent":
        return <Badge className="bg-orange-100 text-orange-800">Urgent</Badge>
      case "Important":
        return <Badge className="bg-yellow-100 text-yellow-800">Important</Badge>
      default:
        return <Badge variant="outline">Normal</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Suivi des plaintes</h1>
          <p className="text-gray-600 mt-2">Gestion et suivi de toutes les plaintes enregistrées</p>
        </div>
        <Button>
          <MessageSquare className="h-4 w-4 mr-2" />
          Nouvelle plainte
        </Button>
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total plaintes</CardTitle>
            <MessageSquare className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{complaints.length}</div>
            <p className="text-xs text-gray-600">+3 cette semaine</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En traitement</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {complaints.filter((c) => ["En cours", "Assignée"].includes(c.status)).length}
            </div>
            <p className="text-xs text-gray-600">en cours</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Urgentes</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {complaints.filter((c) => ["Urgent", "Très urgent"].includes(c.priority)).length}
            </div>
            <p className="text-xs text-gray-600">nécessitent attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Résolues</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {complaints.filter((c) => ["Résolue", "Clôturée"].includes(c.status)).length}
            </div>
            <p className="text-xs text-gray-600">ce mois</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtres et recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Rechercher par numéro, nom du plaignant ou localisation..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Tous les statuts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Enregistrée">Tous les statuts</SelectItem>
                <SelectItem value="Enregistrée">Enregistrée</SelectItem>
                <SelectItem value="Assignée">Assignée</SelectItem>
                <SelectItem value="En cours">En cours</SelectItem>
                <SelectItem value="Résolue">Résolue</SelectItem>
                <SelectItem value="En recours">En recours</SelectItem>
                <SelectItem value="Clôturée">Clôturée</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Toutes les catégories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Catégorie 1">Toutes les catégories</SelectItem>
                <SelectItem value="Catégorie 1">Catégorie 1</SelectItem>
                <SelectItem value="Catégorie 2">Catégorie 2</SelectItem>
                <SelectItem value="Catégorie 3">Catégorie 3</SelectItem>
                <SelectItem value="Catégorie 4">Catégorie 4</SelectItem>
                <SelectItem value="Catégorie 5">Catégorie 5</SelectItem>
                <SelectItem value="Catégorie 6">Catégorie 6</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Période
            </Button>

            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filtres avancés
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des plaintes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageSquare className="h-5 w-5 mr-2" />
            Registre des plaintes ({filteredComplaints.length})
          </CardTitle>
          <CardDescription>Liste complète des plaintes avec leur statut de traitement</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>N° Plainte</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Plaignant</TableHead>
                <TableHead>Catégorie</TableHead>
                <TableHead>Localisation</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Priorité</TableHead>
                <TableHead>Assigné à</TableHead>
                <TableHead>Jours ouverts</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComplaints.map((complaint) => (
                <TableRow key={complaint.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center space-x-2">
                      <span>{complaint.id}</span>
                      {complaint.confidential && (
                        <Badge variant="destructive" className="text-xs">
                          Confidentiel
                        </Badge>
                      )}
                    </div>
                  </TableCell>

                  <TableCell>{complaint.date}</TableCell>

                  <TableCell>
                    <div>
                      <div className="font-medium">{complaint.complainant}</div>
                      <div className="text-xs text-gray-500">{complaint.channel}</div>
                    </div>
                  </TableCell>

                  <TableCell>
                    <div className="text-sm">{complaint.category}</div>
                  </TableCell>

                  <TableCell>
                    <div className="flex items-center text-sm">
                      <MapPin className="h-3 w-3 mr-1 text-gray-400" />
                      {complaint.location}
                    </div>
                  </TableCell>

                  <TableCell>{getStatusBadge(complaint.status)}</TableCell>

                  <TableCell>{getPriorityBadge(complaint.priority)}</TableCell>

                  <TableCell>
                    <div className="flex items-center text-sm">
                      <User className="h-3 w-3 mr-1 text-gray-400" />
                      {complaint.assignedTo}
                    </div>
                  </TableCell>

                  <TableCell>
                    <Badge variant={complaint.daysOpen > 7 ? "destructive" : "outline"}>
                      {complaint.daysOpen} jours
                    </Badge>
                  </TableCell>

                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
