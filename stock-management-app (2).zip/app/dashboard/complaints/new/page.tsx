"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Upload, Save, Send, FileText, MapPin, User, Phone } from "lucide-react"

export default function NewComplaintPage() {
  const [formData, setFormData] = useState({
    // Informations géographiques
    province: "",
    department: "",
    canton: "",
    village: "",

    // Mode de communication
    communicationModes: [] as string[],

    // Données du plaignant
    complainantName: "",
    complainantGender: "",
    complainantPhone: "",
    contactConsent: false,

    // Catégorie et description
    complaintCategory: "",
    complaintDescription: "",

    // Réception
    receivedBy: "",

    // Documents
    attachments: [] as File[],
  })

  const [complaintNumber, setComplaintNumber] = useState("")

  const provinces = ["N'Djamena", "Chari-Baguirmi", "Logone Oriental", "Logone Occidental", "Mayo-Kebbi Est"]
  const departments = ["Département 1", "Département 2", "Département 3"]
  const cantons = ["Canton 1", "Canton 2", "Canton 3"]

  const communicationModes = ["Téléphone", "En personne", "Email", "Courrier postal", "Réseaux sociaux", "Via un tiers"]

  const complaintCategories = [
    { value: "cat1", label: "Catégorie 1 - Mauvaise qualité des services", confidential: false },
    { value: "cat2", label: "Catégorie 2 - Discrimination", confidential: false },
    { value: "cat3", label: "Catégorie 3 - Mauvaise gestion", confidential: false },
    { value: "cat4", label: "Catégorie 4 - Corruption", confidential: false },
    { value: "cat5", label: "Catégorie 5 - Violence", confidential: true },
    { value: "cat6", label: "Catégorie 6 - Exploitation/Abus", confidential: true },
  ]

  const handleCommunicationModeChange = (mode: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        communicationModes: [...formData.communicationModes, mode],
      })
    } else {
      setFormData({
        ...formData,
        communicationModes: formData.communicationModes.filter((m) => m !== mode),
      })
    }
  }

  const handleFileUpload = (files: FileList | null) => {
    if (files) {
      setFormData({
        ...formData,
        attachments: [...formData.attachments, ...Array.from(files)],
      })
    }
  }

  const generateComplaintNumber = () => {
    const date = new Date()
    const year = date.getFullYear()
    const random = Math.floor(Math.random() * 10000)
      .toString()
      .padStart(4, "0")
    return `PLT-${year}-${random}`
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newComplaintNumber = generateComplaintNumber()
    setComplaintNumber(newComplaintNumber)
    console.log("Nouvelle plainte:", { ...formData, complaintNumber: newComplaintNumber })
    // Ici on enverrait les données au serveur
  }

  const selectedCategory = complaintCategories.find((cat) => cat.value === formData.complaintCategory)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Enregistrement d'une nouvelle plainte</h1>
        <p className="text-gray-600 mt-2">Formulaire conforme au modèle papier SWEDD+</p>
      </div>

      {complaintNumber && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Badge className="bg-green-100 text-green-800">Succès</Badge>
              <span className="font-medium">Plainte enregistrée avec le numéro : {complaintNumber}</span>
            </div>
          </CardContent>
        </Card>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Informations géographiques */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="h-5 w-5 mr-2" />
              Informations géographiques
            </CardTitle>
            <CardDescription>Localisation de la plainte</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="province">Province *</Label>
                <Select
                  value={formData.province}
                  onValueChange={(value) => setFormData({ ...formData, province: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner une province" />
                  </SelectTrigger>
                  <SelectContent>
                    {provinces.map((province) => (
                      <SelectItem key={province} value={province}>
                        {province}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Département *</Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => setFormData({ ...formData, department: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un département" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="canton">Canton</Label>
                <Select value={formData.canton} onValueChange={(value) => setFormData({ ...formData, canton: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un canton" />
                  </SelectTrigger>
                  <SelectContent>
                    {cantons.map((canton) => (
                      <SelectItem key={canton} value={canton}>
                        {canton}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="village">Village</Label>
                <Input
                  id="village"
                  value={formData.village}
                  onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                  placeholder="Nom du village"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mode de communication */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Phone className="h-5 w-5 mr-2" />
              Mode de communication de la plainte
            </CardTitle>
            <CardDescription>Comment la plainte a-t-elle été reçue ? (Plusieurs choix possibles)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {communicationModes.map((mode) => (
                <div key={mode} className="flex items-center space-x-2">
                  <Checkbox
                    id={mode}
                    checked={formData.communicationModes.includes(mode)}
                    onCheckedChange={(checked) => handleCommunicationModeChange(mode, checked as boolean)}
                  />
                  <Label htmlFor={mode} className="text-sm">
                    {mode}
                  </Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Données du plaignant */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="h-5 w-5 mr-2" />
              Informations du plaignant
            </CardTitle>
            <CardDescription>Données personnelles (optionnelles si anonyme)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="complainantName">Nom complet</Label>
                <Input
                  id="complainantName"
                  value={formData.complainantName}
                  onChange={(e) => setFormData({ ...formData, complainantName: e.target.value })}
                  placeholder="Nom et prénom du plaignant"
                />
              </div>
              <div className="space-y-2">
                <Label>Sexe</Label>
                <RadioGroup
                  value={formData.complainantGender}
                  onValueChange={(value) => setFormData({ ...formData, complainantGender: value })}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="male" />
                    <Label htmlFor="male">Masculin</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="female" />
                    <Label htmlFor="female">Féminin</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="complainantPhone">Numéro de téléphone</Label>
              <Input
                id="complainantPhone"
                value={formData.complainantPhone}
                onChange={(e) => setFormData({ ...formData, complainantPhone: e.target.value })}
                placeholder="+235 XX XX XX XX"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="contactConsent"
                checked={formData.contactConsent}
                onCheckedChange={(checked) => setFormData({ ...formData, contactConsent: checked as boolean })}
              />
              <Label htmlFor="contactConsent" className="text-sm">
                Le plaignant consent à être contacté pour le suivi de sa plainte
              </Label>
            </div>
          </CardContent>
        </Card>

        {/* Catégorie et description de la plainte */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Détails de la plainte
            </CardTitle>
            <CardDescription>Classification et description de la plainte</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="complaintCategory">Catégorie de plainte *</Label>
              <Select
                value={formData.complaintCategory}
                onValueChange={(value) => setFormData({ ...formData, complaintCategory: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner une catégorie" />
                </SelectTrigger>
                <SelectContent>
                  {complaintCategories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      <div className="flex items-center space-x-2">
                        <span>{category.label}</span>
                        {category.confidential && (
                          <Badge variant="destructive" className="text-xs">
                            Confidentiel
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedCategory?.confidential && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                  <p className="text-sm text-red-800">
                    ⚠️ Cette catégorie nécessite un accès restreint. Seul le coordinateur national pourra accéder aux
                    détails complets.
                  </p>
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="complaintDescription">Description détaillée de la plainte *</Label>
              <Textarea
                id="complaintDescription"
                value={formData.complaintDescription}
                onChange={(e) => setFormData({ ...formData, complaintDescription: e.target.value })}
                placeholder="Décrivez en détail la plainte, les faits, les circonstances..."
                rows={6}
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Documents joints */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="h-5 w-5 mr-2" />
              Documents joints (optionnel)
            </CardTitle>
            <CardDescription>Pièces justificatives, photos, documents de preuve</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="mt-2">
                  <Label htmlFor="file-upload" className="cursor-pointer">
                    <span className="mt-2 block text-sm font-medium text-gray-900">
                      Cliquez pour télécharger des fichiers
                    </span>
                    <span className="mt-1 block text-xs text-gray-500">
                      PDF, Word, Excel, Images (Max 10MB par fichier)
                    </span>
                  </Label>
                  <Input
                    id="file-upload"
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                  />
                </div>
              </div>
              {formData.attachments.length > 0 && (
                <div className="space-y-2">
                  <Label>Fichiers sélectionnés :</Label>
                  {formData.attachments.map((file, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <FileText className="h-4 w-4 text-gray-500" />
                      <span>{file.name}</span>
                      <Badge variant="outline">{(file.size / 1024 / 1024).toFixed(2)} MB</Badge>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Réception */}
        <Card>
          <CardHeader>
            <CardTitle>Informations de réception</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="receivedBy">Plainte reçue par *</Label>
              <Input
                id="receivedBy"
                value={formData.receivedBy}
                onChange={(e) => setFormData({ ...formData, receivedBy: e.target.value })}
                placeholder="Nom et fonction de la personne qui enregistre"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Boutons d'action */}
        <div className="flex space-x-4">
          <Button type="submit" className="flex-1">
            <Save className="h-4 w-4 mr-2" />
            Enregistrer la plainte
          </Button>
          <Button type="button" variant="outline">
            <Send className="h-4 w-4 mr-2" />
            Enregistrer et assigner
          </Button>
        </div>
      </form>
    </div>
  )
}
